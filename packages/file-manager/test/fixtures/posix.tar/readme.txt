body of the brief
